<?php

namespace Arrilot\Widgets\Misc;

use Exception;

class EncryptException extends Exception
{
}
