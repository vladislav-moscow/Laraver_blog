---
name: 🎉 Feature Request
about: You have a neat idea that should be implemented?
labels: type/enhancement
---

<!-- Provide a summary of the feature you would like to see implemented. -->
